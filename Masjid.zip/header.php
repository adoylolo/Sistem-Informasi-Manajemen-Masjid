			<button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <!--/.navbar-header-->
            <div id="main-nav" class="collapse navbar-collapse">
                <nav>
                    <ul class="nav navbar-nav">
                        <li><a href="#top">Home</a></li>
                        <li><a href="#featured">Data Donasi</a></li>
                        <li><a href="#projects">Data Pemasukan</a></li>
                        <li><a href="#video">Data Pengeluaran</a></li>
                        <li><a href="#blog">Blog Entries</a></li>
                        <li><a href="#contact">Contact Us</a></li>
                    </ul>
                </nav>
			<div class="login-panel panel panel-default">
				<div class="panel-heading">Silahkan Login</div>
				<div class="panel-body">
					<form role="form" method="post" action="proseslogin.php">
						<fieldset>
							<div class="form-group">
								<input class="form-control" placeholder="Username" name="username" type="text" autofocus required autocomplete="off"/>
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="Password" name="password" type="password" required autocomplete="off"/>
							</div>
							<br>
							<center>
								<button name="submit" type="submit" class="btn btn-md btn-primary"><i class="fa fa-sign-in"></i> Login</button>
								<button name="reset" type="reset" class="btn btn-md btn-danger"><i class="fa fa-refresh"></i> Reset</button>
							</center>
						</fieldset>
						<hr>
						<div class="text-center">
						<span class="small">
							Belum punya akun? Daftar <a href="signup.php">disini.</a>
						</span>
						</div>
					</form>
					<br><br><br><br><br><br><br><br><br>
					<br><br><br><br><br><br><br><br><br>
				</div>
			</div>
            </div>