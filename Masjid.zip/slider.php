            <div class="Modern-Slider content-section" id="top">
                <!-- Item -->
                <div class="item item-1">
                    <div class="img-fill">
                    <div class="image"></div>
						<div class="info">
                        <div>
                          <h1>Selamat Datang di Website<br>Masjid Al-Ikhlas</h1>
                          <p>Semua yang berkaitan dengan Masjid Al-Ikhlas tersedia di Website ini.</p>
                        </div>
						</div>
                    </div>
                </div>
                <!-- // Item -->
                <!-- Item -->
                <div class="item item-2">
                    <div class="img-fill">
                        <div class="image"></div>
                        <div class="info">
                        <div>
                          <h1>Jadwal Adzan</h1>
                          <p>Kini Anda dapat melihat jadwal lengkap pelaksanaan Ibadah Sholat disini.</p>
                        </div>
                        </div>
                    </div>
                </div>
                <!-- // Item -->
                <!-- Item -->
                <div class="item item-3">
                    <div class="img-fill">
                        <div class="image"></div>
                        <div class="info">
                        <div>
                          <h1>Info dan Agenda Kegiatan</h1>
                          <p>Semua kegiatan yang akan dilaksanakan di Masjid ada disini </p>
                        </div>
                        </div>
                    </div>
                </div>
                <!-- // Item -->
            </div>