           <div class="logo">
                <a href="index.php"><em>Masjid</em> Al-Ikhlas</a>
            </div>
            <nav>
                <ul>
                    <li>
                        <a href="#top">
                            <span class="rect"></span>
                            <span class="circle"></span>
                            Home
                        </a>
                    </li>
                    <li>
                        <a href="#featured">
                            <span class="rect"></span>
                            <span class="circle"></span>
                            Agenda Kegiatan
                        </a>
                    </li>
                    <li>
                        <a href="#projects">
                            <span class="rect"></span>
                            <span class="circle"></span>
                            Jadwal Adzan
                        </a>
                    </li>
                    <li>
                        <a href="#datakeuangan">
                            <span class="rect"></span>
                            <span class="circle"></span>
                            Data Keuangan
                        </a>
                    </li>
                    <li>
                        <a href="#donate">
                            <span class="rect"></span>
                            <span class="circle"></span>
                            Donasi
                        </a>
                    </li>
					<li>
                        <a href="#contact">
                            <span class="rect"></span>
                            <span class="circle"></span>
                           Hubungi Kami
                        </a>
                    </li>
					<li>
                    </li>
					<li>
                    </li>
					<li>
						<input type="button" value="Logout" onclick="window.location.href='logout.php'" />
						<?php
						echo "<script>window.alert('Anda sudah logout
								window.location.href=('index.php')
								</script>";
						?> 
                    </li>
                </ul>
            </nav>
			
            <ul class="social-icons">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                <li><a href="#"><i class="fa fa-rss"></i></a></li>
            </ul>