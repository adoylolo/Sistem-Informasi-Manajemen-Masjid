
           <div class="inner" style="min-height: 700px;">
                <div class="row">
                    <div class="col-lg-12">
                        <h1> Backup Data </h1>
                    </div>
                </div>
                  <hr />
                 <div class="col-lg-12">
					<h2>Klik tombol dibawah untuk membackup seluruh data</h2>
					<div class="form-group">
					<form action="" method="POST">
						<a href="contents/database-backup.php" class="btn btn-grad btn-primary btn-lg">
							<i class="icon-download"></i> Backup
						</a>
					</form>
					</div>
                 </div>
            </div>